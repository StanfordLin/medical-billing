/*
////////////
// Sources//
////////////
 */
#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>

#include "unistd.h"
#include "sys/types.h"
#include <sys/stat.h>
/*
  This lays out structure of node in list of room pointers
 */
struct listItem {
  struct Room* roomptr;
  struct listItem* next;
};
/*
struct listItem* create(struct Room* roomptr) {
  struct listItem* new = (struct listItem*)malloc(sizeof(struct listItem));
  new->roomptr = roomptr;
  new->next = NULL;
  return new;
}
*/
/*
  This lays out structure of room
 */
struct Room{
  char* name;
  char* roomType;
  struct listItem* head;
  int connectionNumber;
};

/* Returns true if all rooms have 3 to 6 outbound connections, false otherwise
*/
int IsGraphFull(struct Room* rooms)
{
  int i;
  for (i=0; i<7; i++) {
    if(rooms[i].connectionNumber < 3) {
      return 0;
    }
  }
  return 1;
}
/* Returns a random Room, does NOT validate if connection can be added
*/
struct Room GetRandomRoom(struct Room* rooms)
{
  int random = rand() % 7;
  return rooms[random];
}

/* Returns true if a connection can be added from Room x (< 6 outbound connections), false otherwise
*/
int CanAddConnectionFrom(struct Room x)
{
  if(x.connectionNumber<5) {
    return 1;
  }
  return 0;
}
/* Returns true if a connection from Room x to Room y already exists, false otherwise
*/
int ConnectionAlreadyExists(struct Room x, struct Room y)
{
  if (x.head == NULL){
    return 0;
  }
  struct listItem* listIter = x.head;
  int i;
  for(i=0; i<7; i++) {
    if(listIter->roomptr->name == y.name){
      return 1;
    }
    if(listIter->next == NULL) {
      break;
    }
    listIter = listIter->next;
  }
  return 0;
}

/* Connects Rooms x and y together, does not check if this connection is valid
*/
void ConnectRoom(struct Room* x, struct Room* y){
  if (x->head == NULL){
    struct listItem* new = (struct listItem*)malloc(sizeof(struct listItem));
    new->roomptr = y;
    new->next = NULL;

    x->head = new;
    return;
  }
  struct listItem* listIter = x->head;
  while(listIter->next != NULL) {
    listIter = listIter->next;
  }

  struct listItem* new = (struct listItem*)malloc(sizeof(struct listItem));
  new->roomptr = y;
  new->next = NULL;
  listIter->next=new;

  x->connectionNumber++;
}

/*
Returns true if Rooms x and y are the same Room, false otherwise
*/
int IsSameRoom(struct Room x, struct Room y)
{
  if (x.name == y.name) {
    return 1;
  }
  return 0;
}

/* Adds a random, valid outbound connection from a Room to another
Room
*/
void AddRandomConnection(struct Room* rooms)
{
  int a;
  int b;

  while(1)
  {
    a = rand() % 7;

    if (CanAddConnectionFrom(rooms[a]) == 1){
      break;
    }
  }

  do
  {
    b = rand() % 7;
  }while(CanAddConnectionFrom(rooms[a]) == 0 || IsSameRoom(rooms[a], rooms[b]) == 1 || ConnectionAlreadyExists(rooms[a], rooms[b]) == 1 || ConnectionAlreadyExists(rooms[b], rooms[a]) == 1);

  ConnectRoom(&rooms[a], &rooms[b]);  /* TODO: Add this connection to the real variables,*/
  ConnectRoom(&rooms[b], &rooms[a]);  /*  because this A and B will be destroyed when this function terminates*/

}
/**
 * [nameGenerator picks 7 names for rooms out of 10 possible,
 * assigns them to rooms]
 * @param rooms [rooms which will have names assigned to them]
 */
void nameGenerator(struct Room* rooms) {

  char* roomStrings[] = {"swamp","castle","plains","rocks","woods",
                         "dungeon","mountain","wall","jungle","house"};
  int chosenArray[10] = {0};

  int j;
  int random;
  for(j=0; j<7;) {
    random = rand() % 10;

    if (chosenArray[random] == 0) {
      chosenArray[random] = 1;
      j++;
    }
  }

  int i;
  int k=0;
  for(i=0; i<10; i++) {
    if (chosenArray[i] == 1) {
      rooms[k].name = malloc(sizeof(roomStrings[i]));
      strcpy(rooms[k].name,roomStrings[i]);
      k++;
    }
  }
}
/**
 * [fileIO outputs room information to file in folder named by
 * dirString]
 * @param room      [room with information used to create file]
 * @param dirString [names folder in which to put files]
 */
void fileIO(struct Room room,char* dirString) {
  FILE *fp;
  char * fileString;
  asprintf(&fileString, "%s/%s", dirString,room.name);

  fp = fopen(fileString, "w+");
  int connections = 1;
  fprintf(fp,"ROOM NAME: %s\n",room.name);

  struct listItem* listIter = room.head;
  while(1) {
    fprintf(fp,"Connection %d: %s\n",connections,listIter->roomptr->name);
    connections++;
    if(listIter->next == NULL) {
      break;
    }
    listIter = listIter->next;
  }

  fprintf(fp,"ROOM TYPE: %s\n",room.roomType);
  fclose(fp);
  free (fileString);
}
/**
 * [roomWriter decides start mid and endpoints of dungeon game]
 * @param rooms     [list of rooms in game]
 * @param dirString [name of directory created to hold room files]
 */
void roomWriter(struct Room* rooms,char* dirString) {
  int START_ROOM;
  int END_ROOM;
  do{
    START_ROOM = rand() % 7;
    END_ROOM = rand() % 7;
  }while(START_ROOM == END_ROOM);

  int j;
  for (j=0; j<7; j++) {
    if (j == START_ROOM) {
      asprintf(&rooms[j].roomType, "%s","START_ROOM");
    }
    else if (j == END_ROOM) {
      asprintf(&rooms[j].roomType, "%s","END_ROOM");
    }
    else{
      asprintf(&rooms[j].roomType, "%s","MID_ROOM");
    }
  }

  int i;
  for(i=0; i<7; i++) {
    fileIO(rooms[i],dirString);
  }
}
/**
 * [creates output directory using pid and passes it to roomWriter]
 */
void directoryMaker(struct Room* rooms) {

  char dirString[] = "grimshaa.rooms.";

  char* str = malloc(sizeof(char)*(int)(getpid())+sizeof(dirString));
  sprintf(str,"grimshaa.rooms.%d",getpid());

  mkdir(str,0777);
  roomWriter(rooms,str);
  free(str);
}
/**
 * [frees linked list of nodes that point to rooms]
 */
void freeList(struct listItem* head) {
  struct listItem* listIter;
  while(head != NULL){
    listIter = head;
    head = head->next;
    free(listIter);
  }
}
/**
 * [cleanup frees heap data associated with room and calls freelist
 * to free linked list of pointers]
 * @param rooms [room to be freed]
 */
void cleanup(struct Room* rooms) {
  int i;
  for(i=0; i<7; i++){
    freeList(rooms[i].head);
    free(rooms[i].name);
    free(rooms[i].roomType);
  }
}
/* Creates all connections in graph
*/
int main()
{
/*
  this block of code creates preconditins for functions to run
 */
  srand(time(NULL));
  struct Room rooms[7];
  int i;
  for(i=0; i<7; i++) {
    rooms[i].connectionNumber = 0;
    rooms[i].head = NULL;
  }
/*
  This block of code generates random names for rooms
 */
  nameGenerator(rooms);
/*
  This block of code adds conections to rooms
 */
  while (IsGraphFull(rooms) == 0)
  {
    AddRandomConnection(rooms);
  }
/*
  This block of code outputs room structs to files in pid folder and cleans up heap memory
 */
  directoryMaker(rooms);
  cleanup(rooms);
  return 0;
}
